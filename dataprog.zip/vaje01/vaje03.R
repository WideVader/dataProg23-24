v1<-c(1,"a",TRUE)
v<-c(1:100)
sum(v)
sum(v^2)
(1:1000)
mean(v)
sum(v)/length(v)
min(v)
max(v)

letters[c(3,2,5)]
letters[5:10]

v[71:100]<-0
v[-1,-70]<-0
v[1:20*5]<--1
v[seq(-5,-100,-5)]<--1