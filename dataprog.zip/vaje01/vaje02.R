v0<-c("table","chair","closet","window")
v0[4] = "shelf"
v1<-c(1,4,3,15,75)
v2<-c(5,6,0,sqrt(2),-4)
v1<-v1*3
v2<-v2*2
v1+v2
sum(v1*v2)
c(v1,v2)
